To switch the restaurants, click their names at the top
To add an order, click the plus sign next to the items
To remove an item click the subtract sign in the order summary
Default Restaurant is first restaurant (Aragon's Orc BBQ)
Could not get items to stack into units :(.
added a theme similar to Uber Eats, added fix posistioning for categories, and order info and summary
added a theme to the menu so that it looks like a menu. added a hover over restaurant names and categories
Went with an 80s/90s font